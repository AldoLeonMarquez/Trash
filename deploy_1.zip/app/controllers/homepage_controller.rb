class HomepageController < ApplicationController
  def index
  end
end
